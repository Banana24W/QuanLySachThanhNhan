package vn.edu.stu.vothanhnhan_dh51900261;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import vn.edu.stu.vothanhnhan_dh51900261.adapter.MonAnAdapter;
import vn.edu.stu.vothanhnhan_dh51900261.model.MonAn;

public class MainActivity extends AppCompatActivity {

    final String SERVER ="https://dichvuseogiatot.com/api6/api.php";
    Button btnThem;
    ArrayList<MonAn> dsMonan;
    ArrayAdapter<MonAn> adapter;
    ListView lvmonan;
    MonAn chon=null;
    EditText edtenmon;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addControls();
        hienthiDanhSach();
        addEvents();
    }
    private void addControls() {
        edtenmon=findViewById(R.id.edTen);
        btnThem=findViewById(R.id.btnThem);
        lvmonan=findViewById(R.id.lvMan);
        dsMonan=new ArrayList<>();
        adapter=new ArrayAdapter<>(
                MainActivity.this,
                android.R.layout.simple_list_item_1,
                dsMonan
        );
        lvmonan.setAdapter(adapter);

    }
    private void addEvents() {
        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(chon==null)
                {
                    String tenSv=edtenmon.getText().toString();
                    MonAn sv=new MonAn(tenSv);
                    Xulithemsv(sv);
                    edtenmon.setText("");
                }
                else {
                    String tenSv=edtenmon.getText().toString();
                    chon.setTen(tenSv);
                    xulycapnhat(chon);
                    chon=null;
                    edtenmon.setText("");
                }
            }
        });
        lvmonan.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(i>=0&&i<dsMonan.size())
                {
                    MonAn sv=dsMonan.get(i);
                    xulyxoa(sv);
                }

                return true;
            }
        });
        lvmonan.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i>=0&&i<dsMonan.size())
                {
                    chon=dsMonan.get(i);
                    edtenmon.setText(chon.getTen());

                }
            }
        });
    }

    private void xulyxoa(MonAn sv) {
    }

    private void xulycapnhat(MonAn chon) {
    }

    private void Xulithemsv(MonAn sv) {
        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
        Response.Listener<String> reStringListener=new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    boolean result=jsonObject.getBoolean("message");
                    if (result){
                        Toast.makeText(
                                MainActivity.this,
                                "Them Thanh Cong",
                                Toast.LENGTH_SHORT
                        ).show();
                        hienthiDanhSach();
                    }
                    else {
                        Toast.makeText(
                                MainActivity.this,
                                "Them That Bai",
                                Toast.LENGTH_SHORT
                        ).show();
                    }
                } catch (JSONException e) {

                }
            }
        };
        Response.ErrorListener errorListener=new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this,error.getMessage(),Toast.LENGTH_LONG).show();
            }
        };
        Uri.Builder builder=Uri.parse(SERVER).buildUpon();
        builder.appendQueryParameter("action","insertmonan");
        builder.appendQueryParameter("mssv","dh51900261");
        builder.appendQueryParameter("name",sv.getTen());
        String url=builder.build().toString();
        StringRequest request=new StringRequest(
                Request.Method.GET,
                url,
                reStringListener,
                errorListener
        );
        request.setRetryPolicy(
                new DefaultRetryPolicy(DefaultRetryPolicy.DEFAULT_TIMEOUT_MS,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
                ));
        requestQueue.add(request);
    }
    /////////////////////////////////
    private void hienthiDanhSach() {
        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);

        Response.Listener<String>reStringListener=new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    dsMonan.clear();
                    JSONArray jsonArray=new JSONArray(response);
                    int len =jsonArray.length();
                    for (int i=0;i<len;i++)
                    {
                        JSONObject jsonObject=jsonArray.getJSONObject(i);
                        int ma=jsonObject.getInt("idmonan");
                        String ten=jsonObject.getString("name");
                        dsMonan.add(new MonAn(ma,ten));
                    }
                    Toast.makeText(
                            MainActivity.this,
                            "Kết Nối Thành Công",
                            Toast.LENGTH_LONG
                    ).show();
                    adapter.notifyDataSetChanged();
                } catch (JSONException e) {

                }
            }
        };
        Response.ErrorListener errorListener=new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(
                        MainActivity.this,
                        "Kết Nối Thất Bại",
                        Toast.LENGTH_LONG
                ).show();
            }
        };
        Uri.Builder builder=Uri.parse(SERVER).buildUpon();
        builder.appendQueryParameter("action","getallmonan");
        builder.appendQueryParameter("mssv","DH51900261");
        String url=builder.build().toString();
        StringRequest request=new StringRequest(
                Request.Method.GET,
                url,
                reStringListener,
                errorListener
        );
        request.setRetryPolicy(
                new DefaultRetryPolicy(
                        DefaultRetryPolicy.DEFAULT_TIMEOUT_MS,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
                ));
        requestQueue.add(request);

    }
}