package vn.edu.stu.vothanhnhan_dh51900261;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CustomView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_view);
    }
}