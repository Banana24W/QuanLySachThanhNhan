package vn.edu.stu.vothanhnhan_dh51900261.model;

public class MonAn {
    private int ma;
    private  String Ten;

    public MonAn(int ma, String ten) {
        this.ma = ma;
        Ten = ten;
    }

    public MonAn(String ten) {
        Ten = ten;
    }

    public MonAn() {
    }

    public int getMa() {
        return ma;
    }

    public void setMa(int ma) {
        this.ma = ma;
    }

    public String getTen() {
        return Ten;
    }

    public void setTen(String ten) {
        Ten = ten;
    }

    @Override
    public String toString() {
        return
                "Ma :" + ma +'\n'+
                "Ten: " + Ten ;
    }
}
