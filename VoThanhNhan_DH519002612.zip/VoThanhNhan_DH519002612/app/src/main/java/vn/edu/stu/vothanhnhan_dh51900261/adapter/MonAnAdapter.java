package vn.edu.stu.vothanhnhan_dh51900261.adapter;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import vn.edu.stu.vothanhnhan_dh51900261.MainActivity;
import vn.edu.stu.vothanhnhan_dh51900261.R;
import vn.edu.stu.vothanhnhan_dh51900261.model.MonAn;

public class MonAnAdapter extends BaseAdapter {
    private List<MonAn> sachList;
    private MainActivity context;
    public MonAnAdapter(MainActivity context, List<MonAn> sachList)
    {
        this.context=context;
        this.sachList=sachList;
    }
    @Override
    public int getCount() {
        return sachList.size();
    }

    @Override
    public Object getItem(int i) {
        return sachList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if (view==null)
        {
            viewHolder=new ViewHolder();
            LayoutInflater inflater=(LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            view=inflater.inflate(R.layout.activity_custom_view ,null);
            viewHolder.txtMa=view.findViewById(R.id.txtMa);
            viewHolder.txtTen=view.findViewById(R.id.txtTen);
//
            view.setTag(viewHolder);
        }
        else {
            viewHolder=(ViewHolder) view.getTag();
        }
        MonAn sach=sachList.get(i);
        viewHolder.txtMa.setText("Ma:"+sach.getMa() );
        viewHolder.txtTen.setText("Ten:"+sach.getTen() );
        return view;
    }
    class ViewHolder{

        TextView txtMa,txtTen;


    }
}
